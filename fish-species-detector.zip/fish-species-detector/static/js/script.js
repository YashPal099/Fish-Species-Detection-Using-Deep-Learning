const dropzone = document.getElementById("dropzone");
const fileInput = document.getElementById("file-input");
const dropzoneContent = document.getElementById("dropzone-content");
const previewImage = document.getElementById("preview-image");
const uploadForm = document.getElementById("upload-form");
const submitBtn = document.getElementById("submit-btn");
const scanningIndicator = document.getElementById("scanning-indicator");
const errorMsg = document.getElementById("error-msg");

const resultCard = document.getElementById("result-card");
const demoBanner = document.getElementById("demo-banner");
const resultImage = document.getElementById("result-image");
const resultConfidenceTag = document.getElementById("result-confidence-tag");
const resultSpeciesName = document.getElementById("result-species-name");
const resultScientificName = document.getElementById("result-scientific-name");
const factGrid = document.getElementById("fact-grid");
const funFactBlock = document.getElementById("fun-fact-block");
const funFactText = document.getElementById("fun-fact-text");
const altPredictions = document.getElementById("alt-predictions");

let selectedFile = null;

function showError(message) {
  errorMsg.textContent = message;
  errorMsg.hidden = false;
}
function clearError() {
  errorMsg.hidden = true;
  errorMsg.textContent = "";
}

function handleFile(file) {
  clearError();
  if (!file) return;
  if (!file.type.startsWith("image/")) {
    showError("Please select an image file (JPG, PNG or WEBP).");
    return;
  }
  selectedFile = file;
  const reader = new FileReader();
  reader.onload = (e) => {
    previewImage.src = e.target.result;
    previewImage.hidden = false;
    dropzoneContent.hidden = true;
  };
  reader.readAsDataURL(file);
  submitBtn.disabled = false;
}

dropzone.addEventListener("click", () => fileInput.click());
fileInput.addEventListener("change", (e) => handleFile(e.target.files[0]));

["dragenter", "dragover"].forEach((evt) => {
  dropzone.addEventListener(evt, (e) => {
    e.preventDefault();
    dropzone.classList.add("dragover");
  });
});
["dragleave", "drop"].forEach((evt) => {
  dropzone.addEventListener(evt, (e) => {
    e.preventDefault();
    dropzone.classList.remove("dragover");
  });
});
dropzone.addEventListener("drop", (e) => {
  const file = e.dataTransfer.files[0];
  handleFile(file);
});

function renderFact(label, value) {
  const dt = document.createElement("dt");
  dt.textContent = label;
  const dd = document.createElement("dd");
  dd.textContent = value;
  factGrid.appendChild(dt);
  factGrid.appendChild(dd);
}

function renderResult(data) {
  resultCard.hidden = false;
  demoBanner.hidden = !data.demo_mode;

  resultImage.src = data.image_url;
  const top = data.predictions[0];
  resultConfidenceTag.textContent = `${top.confidence}% match`;
  resultSpeciesName.textContent = top.species;

  factGrid.innerHTML = "";
  funFactBlock.hidden = true;
  resultScientificName.textContent = "";

  if (data.species_info) {
    const info = data.species_info;
    resultScientificName.textContent = info.scientific_name || "";
    renderFact("Family", info.family || "—");
    renderFact("Habitat", info.habitat || "—");
    renderFact("Diet", info.diet || "—");
    renderFact("Average size", info.avg_size || "—");
    renderFact("Conservation status", info.conservation_status || "—");

    if (info.fun_fact) {
      funFactText.textContent = info.fun_fact;
      funFactBlock.hidden = false;
    }
  }

  altPredictions.innerHTML = "";
  data.predictions.slice(1).forEach((p) => {
    const chip = document.createElement("span");
    chip.className = "alt-chip";
    chip.innerHTML = `<strong>${p.species}</strong> · ${p.confidence}%`;
    altPredictions.appendChild(chip);
  });

  resultCard.scrollIntoView({ behavior: "smooth", block: "nearest" });
}

uploadForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  if (!selectedFile) return;

  clearError();
  resultCard.hidden = true;
  scanningIndicator.hidden = false;
  submitBtn.disabled = true;

  const formData = new FormData();
  formData.append("image", selectedFile);

  try {
    const response = await fetch("/predict", {
      method: "POST",
      body: formData,
    });
    const data = await response.json();

    if (!response.ok) {
      showError(data.error || "Something went wrong. Please try again.");
      return;
    }
    renderResult(data);
  } catch (err) {
    showError("Could not reach the server. Is the Flask app running?");
  } finally {
    scanningIndicator.hidden = true;
    submitBtn.disabled = false;
  }
});
